package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;

import es.unex.pi.dao.JDBCPropertyDAOImpl;
import es.unex.pi.dao.PropertyDAO;
import es.unex.pi.model.Property;
import es.unex.pi.model.User;

/**
 * Servlet implementation class ListPropertiesByUserServlet
 */
@WebServlet("/alojamientos/ListPropertiesGeneralServlet.do")
public class ListPropertiesGeneralServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(HttpServlet.class.getName());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListPropertiesGeneralServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		logger.info("LISTPropertiesBYUSERServlet Atendiendo GET");
		
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		PropertyDAO PropertyDAO = new JDBCPropertyDAOImpl();
		PropertyDAO.setConnection(conn);
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		String disponibilidad = request.getParameter("disponibilidad");
		
		request.setAttribute("disponibilidad",disponibilidad);
		
		if(disponibilidad.equals("disponibles")) {
			List<Property> propertiesList = PropertyDAO.getAllAvailable();
			
			
			if(request.getParameter("categoria") != null) {
				propertiesList = filterByType(propertiesList, request.getParameter("categoria"));
				String categoria = request.getParameter("categoria");
				request.setAttribute("categoria",categoria);
			}
			
			int numpropiedades=propertiesList.size();
			request.setAttribute("numPropiedades",numpropiedades);
			request.setAttribute("propertiesList",propertiesList);
		}
		else if(disponibilidad.equals("nodisponibles")){
			List<Property> propertiesList = PropertyDAO.getAllNotAvailable();
			
			if(request.getParameter("categoria") != null) {
				propertiesList = filterByType(propertiesList, request.getParameter("categoria"));
				String categoria = request.getParameter("categoria");
				request.setAttribute("categoria",categoria);
			}
			
			int numpropiedades=propertiesList.size();
			request.setAttribute("numPropiedades",numpropiedades);
			request.setAttribute("propertiesList",propertiesList);
		}else {
			List<Property> propertiesList = PropertyDAO.getAll();
			
			if(request.getParameter("categoria") != null) {
				propertiesList = filterByType(propertiesList, request.getParameter("categoria"));
				String categoria = request.getParameter("categoria");
				request.setAttribute("categoria",categoria);
			}
			
			int numpropiedades=propertiesList.size();
			request.setAttribute("numPropiedades",numpropiedades);
			request.setAttribute("propertiesList",propertiesList);
		}
				
				
				response.getWriter().append("Served at: ").append(request.getContextPath());
				String titulo="Alojamientos:";
				request.setAttribute("titulo",titulo);
				RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/ExploreProperties.jsp");
				view.forward(request,response);
			

}
    public List<Property> filterByType(List<Property> properties, String type) {
        List<Property> filteredProperties = new ArrayList<>();

        for (Property property : properties) {
            
        	if(property.getType() != null) {
        		if (property.getType().contains(type)) {
                    filteredProperties.add(property);
                }
        	}
        	
        }

        return filteredProperties;
    }
}
