package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.util.logging.Logger;

import es.unex.pi.dao.AccommodationDAO;
import es.unex.pi.dao.JDBCAccommodationDAOImpl;
import es.unex.pi.dao.PropertyDAO;
import es.unex.pi.dao.JDBCPropertyDAOImpl;
import es.unex.pi.model.Accommodation;
import es.unex.pi.model.Property;
import es.unex.pi.model.User;

/**
 * Servlet implementation class DeleteAccommodationServlet
 */
@WebServlet("/users/alojamientos-personales/habitaciones/DeleteAccommodationServlet.do")
public class DeleteAccommodationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(HttpServlet.class.getName());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteAccommodationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		logger.info("DELETEAccommodationServlet Atendiendo Get");
		
		
		int idHabitacion = Integer.parseInt(request.getParameter("id"));
		
		logger.info("DELETEAccommodationServlet EL ID DEL ALOJAMIENTO ES " + idHabitacion);
				
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		AccommodationDAO AccommodationDAO = new JDBCAccommodationDAOImpl();
		AccommodationDAO.setConnection(conn);
		PropertyDAO PropertyDao =new JDBCPropertyDAOImpl();
		PropertyDao.setConnection(conn);
				
		Accommodation accommodation = AccommodationDAO.get(idHabitacion);

		request.setAttribute("idp", accommodation.getIdp());
		request.setAttribute("accommodation", accommodation);
		RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/ConfirmDeletingAccommodation.jsp");
		view.forward(request,response);
		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				logger.info("DELETEAccommodationServlet Atendiendo Post");
				
				int idHabitacion = Integer.parseInt(request.getParameter("id"));
				int idAlojamiento = Integer.parseInt(request.getParameter("idp"));
				
				Connection conn = (Connection) getServletContext().getAttribute("dbConn");
				AccommodationDAO AccommodationDAO = new JDBCAccommodationDAOImpl();
				AccommodationDAO.setConnection(conn);
				
				boolean exito = AccommodationDAO.delete(idHabitacion);
				
				if (exito) {
		            // Si la eliminación fue exitosa, redireccionar a una página de éxito
					response.sendRedirect("ListAccommodationServlet.do?id=" + idAlojamiento);
		        } else {
		            // Si hubo un problema, redireccionar a una página de error
		        	logger.info("DELETEAccommodationServlet ERROR AL ELIMINAR ALOJAMIENTO");
		        	//REDIRECCIONAR A PÁGINA DE ERROR
		        	request.setAttribute("errorMessage", "Ha cocurrido un error al eliminar la habitacion");
		        	RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
					view.forward(request,response);
		        }
	}

}
