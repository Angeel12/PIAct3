package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.util.logging.Logger;

import es.unex.pi.dao.AccommodationDAO;
import es.unex.pi.dao.BookingDAO;
import es.unex.pi.dao.BookingsAccommodationsDAO;
import es.unex.pi.dao.JDBCAccommodationDAOImpl;
import es.unex.pi.dao.JDBCBookingDAOImpl;
import es.unex.pi.dao.JDBCBookingsAccommodationsDAOImpl;
import es.unex.pi.dao.JDBCPropertyDAOImpl;
import es.unex.pi.dao.PropertyDAO;
import es.unex.pi.model.Accommodation;
import es.unex.pi.model.Booking;
import es.unex.pi.model.BookingsAccommodations;
import es.unex.pi.model.Property;
import es.unex.pi.model.User;

/**
 * Servlet implementation class ConfirmBookingServlet
 */
@WebServlet("/users/reservas/ConfirmBookingServlet.do")
public class ConfirmBookingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(HttpServlet.class.getName());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConfirmBookingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		logger.info("CONFIRMBookingServlet Atendiendo Get");
		
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		AccommodationDAO AccommodationDAO = new JDBCAccommodationDAOImpl();
		AccommodationDAO.setConnection(conn);
		
		PropertyDAO PropertyDao =new JDBCPropertyDAOImpl();
		PropertyDao.setConnection(conn);
		
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		
		int idu = (int) user.getId();
		
		int idHabitacion = Integer.parseInt(request.getParameter("ida"));
		int idAlojamiento = Integer.parseInt(request.getParameter("idp"));
		
		
		if(idAlojamiento>0&&PropertyDao.get(idAlojamiento)!=null) {
		
		Property property = PropertyDao.get(idAlojamiento);
		
		if(idHabitacion>0&&AccommodationDAO.get(idHabitacion)!=null) {
			
			Accommodation accommodation = AccommodationDAO.get(idHabitacion);
			
			if (accommodation.getIdp()==idAlojamiento){
				
				int precio = accommodation.getPrice();
				int numNoches = Integer.parseInt(request.getParameter("numNoches"));
				int numHabitaciones = Integer.parseInt(request.getParameter("numHabitaciones"));
				int precioTotal = precio * numNoches * numHabitaciones;
				
				request.setAttribute("idu", idu);
				request.setAttribute("precioTotal", precioTotal);
				request.setAttribute("numHabitaciones", numHabitaciones);
				request.setAttribute("accommodation", accommodation);
				request.setAttribute("property", property);
				
				RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/ConfirmBooking.jsp");
				view.forward(request,response);
			
			}else {
				String errorMessage="¡No tienes permiso para realizar esto!";
				request.setAttribute("errorMessage", errorMessage);
				RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
		    	view.forward(request,response);
			}
		}else {
			String errorMessage="¡No tienes permiso para realizar esto!";
			request.setAttribute("errorMessage", errorMessage);
			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
	    	view.forward(request,response);
		}
		}else {
			String errorMessage="¡No tienes permiso para realizar esto!";
			request.setAttribute("errorMessage", errorMessage);
			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
	    	view.forward(request,response);
		}
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		logger.info("CONFIRMBookingServlet Atendiendo Post");
		
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		BookingDAO BookingDAO = new JDBCBookingDAOImpl();
		BookingDAO.setConnection(conn);
		
		int idu = (int) user.getId();
		int ida = Integer.parseInt(request.getParameter("ida"));
		int precio = Integer.parseInt(request.getParameter("precioTotal"));
		int numHabitaciones = Integer.parseInt(request.getParameter("numHabitaciones")); 
		
		
		Booking booking = new Booking();
		
		booking.setIdu(idu);
		booking.setTotalPrice(precio);
		
		int exito = (int) BookingDAO.add(booking);
		
		if(exito == -1) {
			// Si hubo un problema, redireccionar a una página de error
        	logger.info("CONFIRMBookingServlet ERROR AL CONFIRMAR LA RESERVA");
		}else {
			logger.info("CONFIRMBookingServlet EXITO AL CONFIRMAR LA RESERVA");
			
			Booking bookingAcc = BookingDAO.get(idu, exito);
			int idb = (int) bookingAcc.getId();
			
			BookingsAccommodationsDAO BookingAccommodationDAO = new JDBCBookingsAccommodationsDAOImpl();
			BookingAccommodationDAO.setConnection(conn);
			
			BookingsAccommodations bacc = new BookingsAccommodations();
			
			bacc.setIdacc(ida);
			bacc.setIdb(idb);
			bacc.setNumAccommodations(numHabitaciones);
			
			boolean exito2 = BookingAccommodationDAO.add(bacc);
			
			if(!exito2) {
				logger.info("CONFIRMBookingServlet ERROR AL ASOCIAR LA RESERVA LA RESERVA");
				BookingDAO.delete(idb)	;
				request.setAttribute("errorMessage", "Ha ocurrido un error al realizar la reserva, esa habitación esta ocupada");
				RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
				view.forward(request,response);
			}else {
				request.setAttribute("msgSuccess", "Tu reserva se ha realizado con exito");
				request.setAttribute("path", request.getContextPath()+"/PagPrincipal.do");
				RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Success.jsp");
				view.forward(request,response);
			}
		
		}
		
		
	}

}
