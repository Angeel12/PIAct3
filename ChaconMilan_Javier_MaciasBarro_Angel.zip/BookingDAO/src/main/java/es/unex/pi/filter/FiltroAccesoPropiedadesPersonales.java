package es.unex.pi.filter;

import jakarta.servlet.DispatcherType;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;

import es.unex.pi.dao.JDBCPropertyDAOImpl;
import es.unex.pi.dao.PropertyDAO;
import es.unex.pi.model.Property;
import es.unex.pi.model.User;

/**
 * Servlet Filter implementation class FiltroAccesoPersonal
 */
@WebFilter(dispatcherTypes = {DispatcherType.REQUEST } ,urlPatterns = { "/users/alojamientos-personales/EditPropertyServlet.do", "/users/alojamientos-personales/DeletePropertyServlet.do" })
public class FiltroAccesoPropiedadesPersonales extends HttpFilter implements Filter {
       


	/**
     * @see HttpFilter#HttpFilter()
     */
    public FiltroAccesoPropiedadesPersonales() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		HttpSession session = req.getSession(true);
		
		Connection conn = (Connection) req.getServletContext().getAttribute("dbConn");
		PropertyDAO PropertyDAO = new JDBCPropertyDAOImpl();
		PropertyDAO.setConnection(conn);
		User user = (User) session.getAttribute("user");
		boolean valido=false;
		Property property;
		
		
		if(user!=null) {
		if(request.getParameter("id")!=null) {
		
	     int idAlojamiento = Integer.parseInt(request.getParameter("id"));
	     
	     if(PropertyDAO.get(idAlojamiento)!=null) {
	    	 property=PropertyDAO.get(idAlojamiento);
	    	 if(property.getIdu()==user.getId()){
	    		 valido = true;
	    	 }
	     }
	     
		}

	}
		
		
		if(valido) {
			chain.doFilter(request, response);

		}
		else {
			String errorMessage="¡No tienes permiso para realizar esto!";
			req.setAttribute("errorMessage", errorMessage);
			RequestDispatcher view = req.getRequestDispatcher("/WEB-INF/Error.jsp");
	    	view.forward(req,res);

		}
		
}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
