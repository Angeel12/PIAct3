package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;
import java.util.logging.Logger;

import es.unex.pi.dao.JDBCAccommodationDAOImpl;
import es.unex.pi.dao.JDBCPropertyDAOImpl;
import es.unex.pi.dao.PropertyDAO;
import es.unex.pi.dao.AccommodationDAO;
import es.unex.pi.model.Accommodation;
import es.unex.pi.model.Property;
import es.unex.pi.model.User;

/**
 * Servlet implementation class ListAccommodationServlet
 */
@WebServlet("/users/alojamientos-personales/habitaciones/ListAccommodationServlet.do")
public class ListAccommodationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(HttpServlet.class.getName());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListAccommodationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		logger.info("LISTAccommodationServlet Atendiendo GET");
		
		
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		AccommodationDAO AccommodationDAO = new JDBCAccommodationDAOImpl();
		AccommodationDAO.setConnection(conn);
		PropertyDAO PropertyDao =new JDBCPropertyDAOImpl();
		PropertyDao.setConnection(conn);
		
		logger.info("LISTAccommodationServlet EL ID DEL ALOJAMIENTO ES"+ request.getParameter("id") + "//////////////////////////////");
		int idAlojamiento = Integer.parseInt(request.getParameter("id"));
				
		Property property=PropertyDao.get(idAlojamiento);

		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		
		if(property!=null&&property.getIdu()==user.getId()) {
		
		
		List<Accommodation> accommodationList = AccommodationDAO.getByProperty(idAlojamiento);	
		
		request.setAttribute("idp", idAlojamiento);
		request.setAttribute("accommodationList",accommodationList);
		response.getWriter().append("Served at: ").append(request.getContextPath());
				
		RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/ListAccommodations.jsp");
		view.forward(request,response);
		}
		
		else {
			String errorMessage="¡No tienes acceso a esta página!";
			request.setAttribute("errorMessage", errorMessage);
			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
	    	view.forward(request,response);
		}
	}

}
