package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;

import es.unex.pi.dao.JDBCUserDAOImpl;
import es.unex.pi.dao.UserDAO;
import es.unex.pi.model.User;

/**
 * Servlet implementation class editarPerfilServlet
 */

@WebServlet("/users/EditarPerfilServlet.do")
public class EditarPerfilServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditarPerfilServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		User usuario = (User) session.getAttribute("user");
		
		
		request.setAttribute("user", usuario);
		RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/UserInfo.jsp");
    	view.forward(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		UserDAO UserDAO = new JDBCUserDAOImpl();
		UserDAO.setConnection(conn);
		HttpSession session = request.getSession();

		
		User user = (User) session.getAttribute("user");
		
		user.setEmail(request.getParameter("correoUsuario"));
		user.setName(request.getParameter("nombre"));
		user.setSurname(request.getParameter("apellidos"));
		user.setPassword(request.getParameter("password"));
		
		if(UserDAO.update(user)) {
		session.removeAttribute("user")	;
		session.setAttribute("user", user);
		response.sendRedirect("PagPrincipal.do");
		
		}else {
			//REDIRECCIONAR A PÁGINA DE ERROR
	    	request.setAttribute("errorMessage", "Ha cocurrido un error al editar el perfil");
	    	RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
	    	view.forward(request,response);
		}

	}

}
