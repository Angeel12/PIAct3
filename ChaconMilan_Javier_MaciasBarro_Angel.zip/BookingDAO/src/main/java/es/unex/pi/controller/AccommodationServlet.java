package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.util.logging.Logger;

import es.unex.pi.dao.AccommodationDAO;
import es.unex.pi.dao.JDBCAccommodationDAOImpl;
import es.unex.pi.model.Accommodation;

/**
 * Servlet implementation class AccommodationServlet
 */
@WebServlet("/users/alojamientos-personales/habitaciones/AccommodationServlet.do")
public class AccommodationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(HttpServlet.class.getName());       
    
	/**
     * @see HttpServlet#HttpServlet()
     */
    public AccommodationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		logger.info("ACCOMMODATIONServlet Atendiendo Get");
		
		try {
			int idAlojamiento = Integer.parseInt(request.getParameter("idp"));
			
			logger.info("ACCOMMODATIONServlet LA PROPERTY TIENE EL ID: " + idAlojamiento);
			
			request.setAttribute("idp", idAlojamiento);
			request.setAttribute("method", "create");
			request.setAttribute("pageTitle", "Crear Habitacion");
			
			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Accommodation.jsp");
			view.forward(request,response);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		logger.info("ACCOMMODATIONServlet Atendiendo Post");
		
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		AccommodationDAO AccommodationDAO = new JDBCAccommodationDAOImpl();
		AccommodationDAO.setConnection(conn);
		
		Accommodation accommodation = new Accommodation();
		int idAlojamiento = Integer.parseInt(request.getParameter("idp"));
		//IMPLEMENTAR EL AÑADIR, TENER EN CUENTA QUE TENEMOS QUE ARRASTRAR EL ID DE LA PROPERTY
		accommodation.setName(request.getParameter("nombreHabitacion"));
		accommodation.setPrice(Integer.parseInt(request.getParameter("precio")));
		accommodation.setNumAccommodations(Integer.parseInt(request.getParameter("numHabitaciones")));
		accommodation.setDescription(request.getParameter("descripcion"));
		accommodation.setIdp(idAlojamiento);
		
		long error = AccommodationDAO.add(accommodation);
        
        if(error < 0) {
        	//REDIRECCIONAR A PÁGINA DE ERROR
        	request.setAttribute("errorMessage", "Ha cocurrido un error al añadir una habitacion");
        	RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
        	view.forward(request,response);
        	
        	
        }else {
        	//REDIRECCIONAR A SERVLET QUE LLEVE UNA PAGINA QUE MUESTRE ALOJAMIENTOS
        	response.sendRedirect("ListAccommodationServlet.do?id=" + idAlojamiento);
        }
		
	}

}
