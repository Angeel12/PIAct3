package es.unex.pi.filter;

import jakarta.servlet.DispatcherType;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;

import es.unex.pi.dao.AccommodationDAO;
import es.unex.pi.dao.JDBCAccommodationDAOImpl;
import es.unex.pi.dao.JDBCPropertyDAOImpl;
import es.unex.pi.dao.PropertyDAO;
import es.unex.pi.model.Accommodation;
import es.unex.pi.model.Property;
import es.unex.pi.model.User;

/**
 * Servlet Filter implementation class FiltroAccesoHabitacionesPersonales
 */
@WebFilter(dispatcherTypes = { DispatcherType.REQUEST }, urlPatterns = {
		"/users/alojamientos-personales/habitaciones/DeleteAccommodationServlet.do",
		"/users/alojamientos-personales/habitaciones/EditAccommodationServlet.do" })
public class FiltroAccesoHabitacionesPersonales extends HttpFilter implements Filter {

	/**
	 * @see HttpFilter#HttpFilter()
	 */
	public FiltroAccesoHabitacionesPersonales() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		HttpSession session = req.getSession(true);

		Connection conn = (Connection) req.getServletContext().getAttribute("dbConn");
		AccommodationDAO AccommodationDAO = new JDBCAccommodationDAOImpl();
		AccommodationDAO.setConnection(conn);

		PropertyDAO PropertyDao = new JDBCPropertyDAOImpl();
		PropertyDao.setConnection(conn);

		boolean valido = false;

		User user = (User) session.getAttribute("user");

		if (user != null) {
			if (request.getParameter("id") != null) {

				int idHabitacion = Integer.parseInt(request.getParameter("id"));

				if (AccommodationDAO.get(idHabitacion) != null) {
					Accommodation accommodation = AccommodationDAO.get(idHabitacion);

					long idProperty = accommodation.getIdp();
					Property property = PropertyDao.get(idProperty);

					if (property.getIdu() == user.getId()) {
						valido = true;

					}
				}
			}

		}

		if (valido) {
			chain.doFilter(request, response);
		} else {
			String errorMessage = "¡No tienes acceso a esta página!";
			req.setAttribute("errorMessage", errorMessage);
			RequestDispatcher view = req.getRequestDispatcher("/WEB-INF/Error.jsp");
			view.forward(req, res);
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
