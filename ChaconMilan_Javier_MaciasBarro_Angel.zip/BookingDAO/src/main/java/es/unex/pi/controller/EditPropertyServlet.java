package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.util.logging.Logger;

import es.unex.pi.dao.JDBCPropertyDAOImpl;
import es.unex.pi.dao.PropertyDAO;
import es.unex.pi.model.Property;
import es.unex.pi.model.User;

/**
 * Servlet implementation class EditAlojamientoServlet
 */
@WebServlet("/users/alojamientos-personales/EditPropertyServlet.do")
public class EditPropertyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(HttpServlet.class.getName());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditPropertyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		logger.info("EDITPropertyServlet Atendiendo Get");
		
		int idAlojamiento = Integer.parseInt(request.getParameter("id"));
		
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		PropertyDAO PropertyDAO = new JDBCPropertyDAOImpl();
		PropertyDAO.setConnection(conn);
		
		Property property = PropertyDAO.get(idAlojamiento);


			request.setAttribute("method", "edit");
			request.setAttribute("property", property);
			request.setAttribute("pageTitle", "Editar Alojamiento");
			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Property.jsp");
	    	view.forward(request,response);
			logger.info(property.getEnlaceMaps());

		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		logger.info("EDITPropertyServlet Atendiendo Post");
		
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		PropertyDAO PropertyDAO = new JDBCPropertyDAOImpl();
		PropertyDAO.setConnection(conn);
		
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		
		Property property = new Property();
		
		//Set the different attributes of the Property object with the parameters obtained from the form in the jsp 
		property.setId(Integer.parseInt(request.getParameter("id")));
		property.setName(request.getParameter("nombreAlojamiento"));
		property.setAddress(request.getParameter("direccion"));
		property.setCity(request.getParameter("ciudad"));
		property.setTelephone(request.getParameter("telefono"));
		double centerDistance = Double.parseDouble(request.getParameter("distanciaCentro"));
		property.setCenterDistance(centerDistance);
		property.setEnlaceMaps(request.getParameter("enlaceMaps"));
		property.setDescription(request.getParameter("descripcion"));
		property.setIdu((int) user.getId());
		
		String[] serviciosSeleccionados = request.getParameterValues("servicio");
		StringBuilder servicios = new StringBuilder();
		if (serviciosSeleccionados != null) {
		    for (int i = 0; i < serviciosSeleccionados.length; i++) {
		        servicios.append(serviciosSeleccionados[i]);
		        // Si no es el último elemento, agrega una coma y un espacio
		        if (i < serviciosSeleccionados.length - 1) {
		            servicios.append(", ");
		        }
		    }
		}
        property.setServices(servicios.toString());
        
        String[] tiposSeleccionados = request.getParameterValues("categoria");
		StringBuilder categorias = new StringBuilder();
		if (tiposSeleccionados != null) {
		    for (int i = 0; i < tiposSeleccionados.length; i++) {
		    	categorias.append(tiposSeleccionados[i]);
		        // Si no es el último elemento, agrega una coma y un espacio
		        if (i < tiposSeleccionados.length - 1) {
		        	categorias.append(", ");
		        }
		    }
		}
		
        property.setType(categorias.toString());
        
        String permiteMascotas = request.getParameter("mascotas");
        int petFriendly = permiteMascotas.equals("si") ? 1 : 0;
        property.setPetFriendly(petFriendly);
        
        String disponible = request.getParameter("disponible");
        int available = disponible.equals("si") ? 1 : 0;
        property.setAvailable(available);
        
        
        boolean exito = PropertyDAO.update(property);
        
        if(exito) {
        	//REDIRECCIONAR A SERVLET QUE LLEVE UNA PAGINA QUE MUESTRE ALOJAMIENTOS
        	response.sendRedirect("ListPropertiesByUserServlet.do");
        }
        else {
        	//REDIRECCIONAR A PÁGINA DE ERROR
        	logger.info("EDITPropertyServlet ERROR AL EDITAR EL ALOJAMIENTO");
        	request.setAttribute("errorMessage", "Ha cocurrido un error al editar el alojamiento");
        	RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
        	view.forward(request,response);
        }
	}

}
