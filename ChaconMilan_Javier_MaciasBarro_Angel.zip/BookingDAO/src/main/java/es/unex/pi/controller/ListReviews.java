package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import es.unex.pi.dao.JDBCPropertyDAOImpl;
import es.unex.pi.dao.JDBCReviewDAOImpl;
import es.unex.pi.dao.PropertyDAO;
import es.unex.pi.dao.ReviewDAO;
import es.unex.pi.model.Property;
import es.unex.pi.model.Review;
import es.unex.pi.model.User;

/**
 * Servlet implementation class ListReviews
 */
@WebServlet("/users/ListReviews.do")

public class ListReviews extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListReviews() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		ReviewDAO ReviewDAO = new JDBCReviewDAOImpl();
		ReviewDAO.setConnection(conn);
		PropertyDAO PropertyDAO = new JDBCPropertyDAOImpl();
		PropertyDAO.setConnection(conn);
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		
		
		List<Review> ReviewsList = ReviewDAO.getAllByUser(user.getId());
		boolean Reviews=false;
		
		if(!ReviewsList.isEmpty()) {
			Reviews=true;
			Map<Property, Review> propertyReviews = new HashMap<>();
		for (Review r:ReviewsList){
			Property p=PropertyDAO.get(r.getIdp());
            propertyReviews.put(p, r);
		
        }
		request.setAttribute("reviewList",propertyReviews);
		}
		
		request.setAttribute("Reviews",Reviews);
		
		RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/ListReviews.jsp");
		view.forward(request,response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
