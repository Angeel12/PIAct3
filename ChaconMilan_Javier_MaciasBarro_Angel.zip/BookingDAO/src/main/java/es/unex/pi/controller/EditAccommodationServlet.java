package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.util.logging.Logger;

import es.unex.pi.dao.AccommodationDAO;
import es.unex.pi.dao.JDBCAccommodationDAOImpl;
import es.unex.pi.model.Accommodation;

import es.unex.pi.dao.PropertyDAO;
import es.unex.pi.dao.JDBCPropertyDAOImpl;
import es.unex.pi.model.Property;
import es.unex.pi.model.User;

/**
 * Servlet implementation class EditAccommodationServlet
 */
@WebServlet("/users/alojamientos-personales/habitaciones/EditAccommodationServlet.do")
public class EditAccommodationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(HttpServlet.class.getName());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditAccommodationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		logger.info("EDITAccommodationServlet Atendiendo Get");
		
		int idHabitacion = Integer.parseInt(request.getParameter("id"));
		
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		AccommodationDAO AccommodationDAO = new JDBCAccommodationDAOImpl();
		AccommodationDAO.setConnection(conn);
		PropertyDAO PropertyDao =new JDBCPropertyDAOImpl();
		PropertyDao.setConnection(conn);
		
		Accommodation accommodation = AccommodationDAO.get(idHabitacion);
		if(accommodation!=null) {
		long idProperty=accommodation.getIdp();
		Property property=PropertyDao.get(idProperty);

		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		
		if(property.getIdu()==user.getId()) {
		
		request.setAttribute("idp", accommodation.getIdp());
		request.setAttribute("method", "edit");
		request.setAttribute("accommodation", accommodation);
		request.setAttribute("pageTitle", "Editar Habitacion");
		RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Accommodation.jsp");
    	view.forward(request,response);
		}
		else {
			String errorMessage="¡No tienes acceso a esta página!";
			request.setAttribute("errorMessage", errorMessage);
			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
	    	view.forward(request,response);
		}
		}
		else {
			String errorMessage="¡No tienes acceso a esta página!";
			request.setAttribute("errorMessage", errorMessage);
			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
	    	view.forward(request,response);
		}
    	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		logger.info("EDITAccommodationServlet Atendiendo Post");
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		AccommodationDAO AccommodationDAO = new JDBCAccommodationDAOImpl();
		AccommodationDAO.setConnection(conn);
		
		Accommodation accommodation = new Accommodation();
		int idAlojamiento = Integer.parseInt(request.getParameter("idp"));
		int idHabitacion = Integer.parseInt(request.getParameter("id"));
		//IMPLEMENTAR EL AÑADIR, TENER EN CUENTA QUE TENEMOS QUE ARRASTRAR EL ID DE LA PROPERTY
		accommodation.setId(idHabitacion);
		accommodation.setName(request.getParameter("nombreHabitacion"));
		accommodation.setPrice(Integer.parseInt(request.getParameter("precio")));
		accommodation.setNumAccommodations(Integer.parseInt(request.getParameter("numHabitaciones")));
		accommodation.setDescription(request.getParameter("descripcion"));
		accommodation.setIdp(idAlojamiento);
		
		boolean exito = AccommodationDAO.update(accommodation);
        
        if(exito) {
        	logger.info("EDITAccommodationServlet EL ID DEL ALOJAMIENTO ES " + idAlojamiento + "////////////////////////////////////////////////");
        	
        	response.sendRedirect("ListAccommodationServlet.do?id=" + idAlojamiento);
        }
        else {
        	//REDIRECCIONAR A PÁGINA DE ERROR
        	logger.info("EDITAccommodationServlet ERROR AL EDITAR EL ALOJAMIENTO");
        	//REDIRECCIONAR A PÁGINA DE ERROR
        	request.setAttribute("errorMessage", "Ha cocurrido un error al editar la habitacion");
        	RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
        	view.forward(request,response);

        }
	}

}
