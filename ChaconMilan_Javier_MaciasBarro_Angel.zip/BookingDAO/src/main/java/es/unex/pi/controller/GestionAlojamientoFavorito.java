package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;

import es.unex.pi.dao.JDBCPropertyDAOImpl;
import es.unex.pi.dao.PropertyDAO;
import es.unex.pi.model.User;

/**
 * Servlet implementation class GestionAlojamientoFavorito
 */
@WebServlet("/users/alojamientos-personales/GestionAlojamientoFavorito.do")

public class GestionAlojamientoFavorito extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GestionAlojamientoFavorito() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String alojamientoId = request.getParameter("alojamiento_id");
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		PropertyDAO PropertyDAO = new JDBCPropertyDAOImpl();
		PropertyDAO.setConnection(conn);
		
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		
		request.setAttribute("esFavorito", PropertyDAO.esFavorito(user.getId(),Long.parseLong(alojamientoId )));
		
        request.setAttribute("alojamientoId", alojamientoId);

        // Redirigir a confirmarFavorito.jsp
        RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/confirmarFavorito.jsp");
        view.forward(request, response);
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    String alojamientoId = request.getParameter("id");
	   
	    
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		PropertyDAO PropertyDAO = new JDBCPropertyDAOImpl();
		PropertyDAO.setConnection(conn);
		
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		
		if(!PropertyDAO.esFavorito(user.getId(),Long.parseLong(alojamientoId ))){
			PropertyDAO.addFavourite(PropertyDAO.get(Long.parseLong(alojamientoId)), user);
		}else {
			PropertyDAO.deleteFavourite(Long.parseLong(alojamientoId), user.getId());

		}
		
		response.sendRedirect(request.getContextPath()+ "/alojamientos/AlojamientoEspecificoServlet.do?id="+alojamientoId);


	}

}
