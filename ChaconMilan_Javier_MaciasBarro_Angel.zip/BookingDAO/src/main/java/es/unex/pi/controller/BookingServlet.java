package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.util.logging.Logger;

import es.unex.pi.dao.AccommodationDAO;
import es.unex.pi.dao.JDBCAccommodationDAOImpl;
import es.unex.pi.dao.JDBCPropertyDAOImpl;
import es.unex.pi.dao.PropertyDAO;
import es.unex.pi.model.Accommodation;
import es.unex.pi.model.Property;

/**
 * Servlet implementation class BookingServlet
 */
@WebServlet("/users/reservas/BookingServlet.do")
public class BookingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(HttpServlet.class.getName());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		logger.info("BOOKINGServlet Atendiendo GET");
		
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		AccommodationDAO AccommodationDAO = new JDBCAccommodationDAOImpl();
		AccommodationDAO.setConnection(conn);
		PropertyDAO PropertyDao =new JDBCPropertyDAOImpl();
		PropertyDao.setConnection(conn);
		
		int idHabitacion = Integer.parseInt(request.getParameter("ida"));
		
		
		
		int idAlojamiento = Integer.parseInt(request.getParameter("idp"));
		
		if(idAlojamiento>0&&PropertyDao.get(idAlojamiento)!=null) {
		
		Property property = PropertyDao.get(idAlojamiento);
		
		
		if(idHabitacion>0&&AccommodationDAO.get(idHabitacion)!=null) {
			
			Accommodation accommodation = AccommodationDAO.get(idHabitacion);
			
			if (accommodation.getIdp()==idAlojamiento){
				request.setAttribute("property", property);
				request.setAttribute("accommodation", accommodation);
				RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Booking.jsp");
				view.forward(request,response);
			
			}else {
				String errorMessage="¡No tienes permiso para realizar esto!";
				request.setAttribute("errorMessage", errorMessage);
				RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
		    	view.forward(request,response);
			}
		}else {
			String errorMessage="¡No tienes permiso para realizar esto!";
			request.setAttribute("errorMessage", errorMessage);
			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
	    	view.forward(request,response);
		}
		}else {
			String errorMessage="¡No tienes permiso para realizar esto!";
			request.setAttribute("errorMessage", errorMessage);
			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
	    	view.forward(request,response);
		}
		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
