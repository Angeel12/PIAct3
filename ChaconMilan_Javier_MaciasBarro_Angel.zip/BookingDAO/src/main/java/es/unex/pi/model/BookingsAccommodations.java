package es.unex.pi.model;

public class BookingsAccommodations {

	private long idb;
	private long idacc;
	private long numAccommodations; 
	
	public long getIdb() {
		return idb;
	}

	public void setIdb(long idb) {
		this.idb = idb;
	}

	public long getIdacc() {
		return idacc;
	}

	public void setIdacc(long idacc) {
		this.idacc = idacc;
	}

	public long getNumAccommodations() {
		return numAccommodations;
	}

	public void setNumAccommodations(long numAccom) {
		this.numAccommodations = numAccom;
	}

}
