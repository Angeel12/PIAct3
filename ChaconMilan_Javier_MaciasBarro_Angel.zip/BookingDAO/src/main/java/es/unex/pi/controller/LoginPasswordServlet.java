package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;

import es.unex.pi.dao.*;
import es.unex.pi.model.*;

/**
 * Servlet implementation class LoginPasswordServlet
 */
@WebServlet("/LoginPasswordServlet.do")

public class LoginPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginPasswordServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/LoginPassword.jsp");
	    dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		UserDAO userDao = new JDBCUserDAOImpl();
		userDao.setConnection(conn);
		
	    HttpSession session = request.getSession();

		String correo = (String) session.getAttribute("correoUsuario");
		String password = request.getParameter("contraseña");

		User user = userDao.get(correo);

		if (user != null && user.getPassword().equals(password)) {
            
		    session.setAttribute("user", user);
		    String pagPrevia=(String) session.getAttribute("pagPrevia");
	        if (pagPrevia != null) {
	            // Redirigir al usuario a la página anterior
	            response.sendRedirect(pagPrevia);
	            // Limpiar la URL de la página anterior almacenada en la sesión
	            session.removeAttribute("pagPrevia");
	        } else {
	            // Si no hay una página anterior, redirigir al usuario a la página principal
	            response.sendRedirect("PagPrincipal.do");
	        }
		} else {
		    request.setAttribute("messages", "Wrong username or password!!");
		    RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/LoginPassword.jsp");
		    view.forward(request, response);
		}
	}

}
