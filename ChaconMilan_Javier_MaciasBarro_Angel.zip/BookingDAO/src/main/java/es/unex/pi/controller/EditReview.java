package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.util.logging.Logger;

import es.unex.pi.dao.JDBCPropertyDAOImpl;
import es.unex.pi.dao.JDBCReviewDAOImpl;
import es.unex.pi.dao.PropertyDAO;
import es.unex.pi.dao.ReviewDAO;
import es.unex.pi.model.Property;
import es.unex.pi.model.Review;
import es.unex.pi.model.User;

/**
 * Servlet implementation class EditReview
 */
@WebServlet("/users/EditReview.do")

public class EditReview extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditReview() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		ReviewDAO ReviewDAO = new JDBCReviewDAOImpl();
		ReviewDAO.setConnection(conn);
		
		PropertyDAO PropertyDAO = new JDBCPropertyDAOImpl();
		PropertyDAO.setConnection(conn);
	
		
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		
		int idu = (int) user.getId();

		int idp = Integer.parseInt(request.getParameter("idp"));
        Logger.getLogger("atribs"+idp);
        
        if(ReviewDAO.get(idp, idu)!=null) {

		Property property = PropertyDAO.get(idp);
		String nombrePropiedad=property.getName();
		
		String comentarioGeneral = request.getParameter("comentarioGeneral");
		String review = request.getParameter("review");
		int rating = Integer.parseInt(request.getParameter("rating"));


		request.setAttribute("comentarioGeneral", comentarioGeneral);
		request.setAttribute("review", review);
		request.setAttribute("rating",rating);
		request.setAttribute("titulo","¿Editar y confirmar esta reseña?");
        request.setAttribute("modo","Edicion" );


		
		request.setAttribute("idu", idu);
		request.setAttribute("idp", idp);


		
		request.setAttribute("nombrePropiedad", nombrePropiedad);
		
		RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/ConfirmReview.jsp");
		view.forward(request,response);
        }
        
        else {
			String errorMessage="¡No ha sido posible editar la reseña para esta propiedad!";
			request.setAttribute("errorMessage", errorMessage);
			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
	    	view.forward(request,response);
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int idp = Integer.parseInt(request.getParameter("idp"));
		int idu = Integer.parseInt(request.getParameter("idu"));

		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		ReviewDAO ReviewDAO = new JDBCReviewDAOImpl();
		ReviewDAO.setConnection(conn);
		
		
		String comentarioGeneral = request.getParameter("comentarioGeneral");
		String review = request.getParameter("review");
		int rating = Integer.parseInt(request.getParameter("rating"));
		
		
		Review Review=new Review();
		
		Review.setIdu(idu);
		Review.setIdp(idp);
		Review.setComment(comentarioGeneral);
		Review.setReview(review);
		Review.setGrade(rating);
		
		if(ReviewDAO.update(Review)) {
			response.sendRedirect(request.getContextPath()+"/alojamientos/AlojamientoEspecificoServlet.do?id="+idp);
			}
			else {
			request.setAttribute("errorMessage", "Ha cocurrido un error al editar la valoracion");
			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
			view.forward(request,response);
			}
	}

}
