package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import es.unex.pi.dao.AccommodationDAO;
import es.unex.pi.dao.BookingDAO;
import es.unex.pi.dao.BookingsAccommodationsDAO;
import es.unex.pi.dao.JDBCAccommodationDAOImpl;
import es.unex.pi.dao.JDBCBookingDAOImpl;
import es.unex.pi.dao.JDBCBookingsAccommodationsDAOImpl;
import es.unex.pi.dao.JDBCPropertyDAOImpl;
import es.unex.pi.dao.PropertyDAO;
import es.unex.pi.model.Accommodation;
import es.unex.pi.model.Booking;
import es.unex.pi.model.BookingsAccommodations;
import es.unex.pi.model.Property;
import es.unex.pi.model.User;
import es.unex.pi.util.Triplet;

/**
 * Servlet implementation class ListBookingServlet
 */
@WebServlet("/users/reservas/ListBookingServlet.do")
public class ListBookingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static final Logger logger = Logger.getLogger(HttpServlet.class.getName());
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListBookingServlet() {
        super();

        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		logger.info("LISTBookingServlet Atendiendo GET");
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		BookingDAO BookingDAO = new JDBCBookingDAOImpl();
		BookingDAO.setConnection(conn);
		
		BookingsAccommodationsDAO BookingAccommodationDAO = new JDBCBookingsAccommodationsDAOImpl();
		BookingAccommodationDAO.setConnection(conn);
		
		AccommodationDAO AccommodationDAO = new JDBCAccommodationDAOImpl();
		AccommodationDAO.setConnection(conn);
		
		PropertyDAO PropertyDAO = new JDBCPropertyDAOImpl();
		PropertyDAO.setConnection(conn);
		
		
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		
		List<Booking> bookingListByUser = BookingDAO.getAllByUser(user.getId());
		List<Triplet<Booking, Accommodation, Property>> bookingList = new ArrayList<>();
		double subtotal=0;
		for (Booking booking : bookingListByUser) {
		    
			BookingsAccommodations bacc = BookingAccommodationDAO.getByBooking(booking.getId());
			logger.info("El id del alojamiento de BACC es : " + bacc.getIdacc() + "///////////////////////////////////////////////////");
			long idacc = bacc.getIdacc();
			Accommodation acc = AccommodationDAO.get(idacc);
			
			logger.info("El id de la propiedad de ACC es : " + acc.getIdp() + "///////////////////////////////////////////////////");
			long idpr = acc.getIdp();
			Property pr = PropertyDAO.get(idpr);
             subtotal=subtotal+booking.getTotalPrice();	
			bookingList.add(new Triplet<>(booking, acc, pr));
		}
		
		request.setAttribute("bookingList",bookingList);
		request.setAttribute("subtotal",subtotal);

		
		response.getWriter().append("Served at: ").append(request.getContextPath());
		RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/ListBooking.jsp");
		view.forward(request,response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
