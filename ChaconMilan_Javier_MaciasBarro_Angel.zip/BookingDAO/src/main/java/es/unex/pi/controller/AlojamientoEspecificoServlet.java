package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.apache.tomcat.jakartaee.commons.lang3.tuple.Pair;

import es.unex.pi.dao.AccommodationDAO;
import es.unex.pi.dao.JDBCAccommodationDAOImpl;
import es.unex.pi.dao.JDBCPropertyDAOImpl;
import es.unex.pi.dao.JDBCReviewDAOImpl;
import es.unex.pi.dao.PropertyDAO;
import es.unex.pi.dao.JDBCUserDAOImpl;
import es.unex.pi.dao.UserDAO;
import es.unex.pi.dao.ReviewDAO;
import es.unex.pi.model.Accommodation;
import es.unex.pi.model.Booking;
import es.unex.pi.model.Property;
import es.unex.pi.model.Review;
import es.unex.pi.model.User;
import es.unex.pi.util.Triplet;

/**
 * Servlet implementation class AlojamientoEspecificoServlet
 */
@WebServlet("/alojamientos/AlojamientoEspecificoServlet.do")

public class AlojamientoEspecificoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(HttpServlet.class.getName());

       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AlojamientoEspecificoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	

		
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		PropertyDAO PropertyDAO = new JDBCPropertyDAOImpl();
		PropertyDAO.setConnection(conn);
		AccommodationDAO AccommodationDAO = new JDBCAccommodationDAOImpl();
		AccommodationDAO.setConnection(conn);
		UserDAO UserDAO = new JDBCUserDAOImpl();
		UserDAO.setConnection(conn);
		
		ReviewDAO ReviewDAO = new JDBCReviewDAOImpl();
		ReviewDAO.setConnection(conn);
		
		
		String alojamientoId = request.getParameter("id");
	    logger.info("id alojamiento "+alojamientoId);
        if(alojamientoId!=null) {
        	if(PropertyDAO.get(Long.parseLong(alojamientoId))!=null){
        Property Propiedad=PropertyDAO.get(Long.parseLong(alojamientoId));
        
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		int idAlojamiento = (int) Propiedad.getId();
		boolean esPropio=false;
		boolean esFavorito=false;
		boolean tieneComentario=false;
		
		if(user!=null) {

		if(user.getId()==Propiedad.getIdu()) {
			esPropio=true;
		}
		if(PropertyDAO.esFavorito(user.getId(),Long.parseLong(alojamientoId ))){
			esFavorito=true;
		}
		
		if(ReviewDAO.get(idAlojamiento, user.getId())!=null) {
			tieneComentario=true;
			Review r=ReviewDAO.get(idAlojamiento, user.getId());
			request.setAttribute("comentarioGeneral", r.getComment());
			request.setAttribute("review", r.getReview());
			request.setAttribute("rating", r.getGrade());
			request.setAttribute("idu",user.getId());


		}
		
		
        
		}
		
		List<Accommodation> accommodationList = AccommodationDAO.getByProperty(idAlojamiento);
	
		
		
		

		
		List<Review> ReviewsList = ReviewDAO.getAllByProperty(idAlojamiento);
		boolean Reviews=false;

		
		if(!ReviewsList.isEmpty()) {
			Reviews=true;
			Map<String, Review> namedReviews = new HashMap<>();
		for (Review r:ReviewsList){
			User s=UserDAO.get(r.getIdu());
            namedReviews.put(s.getName(), r);
			
			
        }
		request.setAttribute("reviewList",namedReviews);
		}

		request.setAttribute("Reviews",Reviews);

		
		
		
		List<Property> alojamientosParecidos = PropertyDAO.getAllBySearchName("", "", Propiedad.getCity(),"disponible");
		boolean hayParecidos=false;
		List<Property> primerosTresAlojamientos=null;

		
		if(alojamientosParecidos.size()>0) {
			hayParecidos=true;
			int numElementos = alojamientosParecidos.size();
			int numElementosAObtener = Math.min(numElementos, 3);
			primerosTresAlojamientos = alojamientosParecidos.subList(0, numElementosAObtener);
			for (Property p : primerosTresAlojamientos) {
			    if (p.getId()==Propiedad.getId()) {
			        primerosTresAlojamientos.remove(p);
			        logger.info("borrado "+p.getName());
			        break; // Importante: salimos del bucle una vez eliminado el elemento
			    }
			}


		}

		boolean hayHabitaciones=false;
		if(!accommodationList.isEmpty()) {
			hayHabitaciones=true;
		}
		
		request.setAttribute("hayHabitaciones", hayHabitaciones);

		request.setAttribute("hayParecidos", hayParecidos);

		request.setAttribute("alojamientosParecidos", primerosTresAlojamientos);
		request.setAttribute("accommodationList",accommodationList);
        request.setAttribute("tieneComentario",tieneComentario);
        request.setAttribute("enlaceMaps", Propiedad.getEnlaceMaps());
        request.setAttribute("esFavorito",esFavorito);
        request.setAttribute("esPropio",  esPropio);
		request.setAttribute("idPropiedad",Propiedad.getId());
		request.setAttribute("nombrePropiedad",Propiedad.getName());
		request.setAttribute("direccionPropiedad", Propiedad.getAddress());
		request.setAttribute("ciudadPropiedad", Propiedad.getCity());
		request.setAttribute("descripcionPropiedad", Propiedad.getDescription());
		request.setAttribute("telefonoPropiedad", Propiedad.getTelephone());
		String servicios=Propiedad.getServices();
		boolean hayServicios=true;
		int petFriendly=Propiedad.getPetFriendly();
		

		
		if(servicios==null||servicios.equals("")&&petFriendly==0) {
			hayServicios=false;
		}
		

		request.setAttribute("petFriendly",petFriendly );

		request.setAttribute("hayServicios",hayServicios );

		request.setAttribute("serviciosPropiedad",servicios );
		request.setAttribute("distanciaCentroPropiedad", Propiedad.getCenterDistance());
		request.setAttribute("gradesAveragePropiedad", Propiedad.getGradesAverage());
		request.setAttribute("disponibilidadPropiedad", Propiedad.getAvailable());

		
		
		RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/AlojamientoEspecifico.jsp");
		view.forward(request,response);
        }
        	
        	else {
        		
        			String errorMessage="¡No tienes acceso a esta página!";
        			request.setAttribute("errorMessage", errorMessage);
        			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
        	    	view.forward(request,response);
        		
        	}
        }
		else {
			String errorMessage="¡No tienes acceso a esta página!";
			request.setAttribute("errorMessage", errorMessage);
			RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
	    	view.forward(request,response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
