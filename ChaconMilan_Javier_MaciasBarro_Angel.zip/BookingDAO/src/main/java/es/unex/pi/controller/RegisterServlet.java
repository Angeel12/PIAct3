package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;

import es.unex.pi.dao.*;
import es.unex.pi.model.User;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet.do")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	    RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/Register.jsp");
	    dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	    HttpSession session = request.getSession();
	    String email=(String) session.getAttribute("correoUsuario");
	    email.toLowerCase();
		User user=new User();
		user.setName(request.getParameter("nombre"));
		user.setEmail(email);
		user.setPassword(request.getParameter("contraseña"));
		user.setSurname(request.getParameter("apellidos"));
		UserDAO userDao= new JDBCUserDAOImpl();
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		userDao.setConnection(conn);
		long id=userDao.add(user);
		session.removeAttribute("correoUsuario");
		
		user.setId(id);
	    session.setAttribute("user", user);
	    response.sendRedirect("PagPrincipal.do");



		
	}

}
