package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;

import es.unex.pi.dao.ReviewDAO;
import es.unex.pi.model.User;
import es.unex.pi.dao.BookingsAccommodationsDAO;
import es.unex.pi.dao.JDBCReviewDAOImpl;
import es.unex.pi.dao.JDBCBookingsAccommodationsDAOImpl;

/**
 * Servlet implementation class DeleteReview
 */
@WebServlet("/users/DeleteReview.do")

public class DeleteReview extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteReview() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int idp = Integer.parseInt(request.getParameter("idp"));
		

		request.setAttribute("idp", idp);
		
		RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/confirmarDeleteReview.jsp");
		view.forward(request,response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		
		int idp = Integer.parseInt(request.getParameter("idp"));
		int idu = (int) user.getId();

		
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		ReviewDAO ReviewDAO = new JDBCReviewDAOImpl();
		ReviewDAO.setConnection(conn);
		
		BookingsAccommodationsDAO BAccDAO = new JDBCBookingsAccommodationsDAOImpl();
		BAccDAO.setConnection(conn);
		
		boolean exito = ReviewDAO.delete(idp,idu);
		
		if (exito) {
			
			response.sendRedirect(request.getContextPath()+"/alojamientos/AlojamientoEspecificoServlet.do?id="+idp);

	}else {
		//REDIRECCIONAR A PÁGINA DE ERROR
		request.setAttribute("errorMessage", "Ha cocurrido un error al eliminar la valoracion");
		RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
		view.forward(request,response);
	}

}
}
