package es.unex.pi.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;

import es.unex.pi.dao.JDBCUserDAOImpl;
import es.unex.pi.dao.UserDAO;
import es.unex.pi.model.User;

/**
 * Servlet implementation class DeleteUser
 */
@WebServlet("/users/DeleteUser.do")
public class DeleteUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/confirmarDeleteUser.jsp");
    	view.forward(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		HttpSession session = request.getSession();
		User usuario = (User) session.getAttribute("user");
		
		Connection conn = (Connection) getServletContext().getAttribute("dbConn");
		UserDAO UserDAO = new JDBCUserDAOImpl();
		UserDAO.setConnection(conn);
		
		boolean exito = UserDAO.delete(usuario.getId());
		session.invalidate();
		
		if (exito) {
            // Si la eliminación fue exitosa, redireccionar a una página de éxito
            response.sendRedirect("PagPrincipal.do");
        } else {
        	//REDIRECCIONAR A PÁGINA DE ERROR
        	request.setAttribute("errorMessage", "Ha cocurrido un error al eliminar el usuario");
        	RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/Error.jsp");
        	view.forward(request,response);
        }
	}

}
